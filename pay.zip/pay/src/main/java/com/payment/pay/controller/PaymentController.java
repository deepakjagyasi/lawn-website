package com.payment.pay.controller;

import com.google.gson.Gson;
import com.payment.pay.client.StripeClient;
import com.payment.pay.exception.InvalidAmountException;
import com.payment.pay.model.ClientInput;
import com.payment.pay.util.ValidationUtil;
import com.stripe.model.PaymentIntent;
import com.stripe.param.PaymentIntentCreateParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    private StripeClient stripeClient;
    private static Gson gson = new Gson();
    
    @Value("${isDummyEnabled}")
    private String isDummyEnabled;
    
    @Value("${validator.whitelist.regex}")
    private String regex;

    @Autowired
    PaymentController(StripeClient stripeClient) {
        this.stripeClient = stripeClient;
    }

    @PostMapping("/charge")
    public ResponseEntity<String> chargeCard(@RequestParam(value = "token", defaultValue="tok_mastercard") String token, 
    		@RequestParam(value = "amount", defaultValue = "0") String amount) throws Exception {
    	if(ValidationUtil.isNullBlankEmpty(token) || 
    			!ValidationUtil.isStringSafe(token, regex)) {
    		throw new Exception("Invalid token:" +token);
    	}
    	
    	double amountindecimal=0.0;
    	try {
    		amountindecimal=Double.parseDouble(amount);
    	}catch(NumberFormatException e){
           throw new Exception("Invalid Amount:" +amount);
        }
        System.out.println("amount="+amount);
        System.out.println("isDummyEnabled?"+isDummyEnabled);
        if(Boolean.parseBoolean(isDummyEnabled))
        	return new ResponseEntity<String>(
        			stripeClient.chargeNewCardDummy(token, amountindecimal).toJson(), HttpStatus.OK);
         return new ResponseEntity<String>(stripeClient.chargeNewCard(token, amountindecimal).toJson(), HttpStatus.OK);
	//return "payment success"; 
        
    }
    
    @PostMapping("/invalidate/session")
    public String destroySession(HttpServletRequest request) {
        //invalidate the session , this will clear the data from configured database (Mysql/redis/hazelcast)
        request.getSession().invalidate();
        return "redirect:/home";
    }
    
    static class CreatePaymentResponse {
        private String clientSecret;

        public CreatePaymentResponse(String clientSecret) {
          this.clientSecret = clientSecret;
        }
      }
    
    @PostMapping("/create-payment-intent")
    public String createPaymentIntent(@RequestBody ClientInput clientInput) 
    		throws Exception { 
    	String currency = clientInput.getCurrency();
    	if(ValidationUtil.isNullBlankEmpty(currency) || 
    			!ValidationUtil.isStringSafe(currency, regex)) {
    		throw new Exception("Invalid currency:" +currency);
    	}
    	long amount = 0;
    	try {
    		amount = (long)clientInput.getItems().get(0).getAmount();
    	}catch(Exception e){
           throw new Exception("Invalid Amount:" +amount);
        }
    	//CreatePayment postBody = gson.fromJson(request.body(), CreatePayment.class);
    	PaymentIntentCreateParams createParams = new PaymentIntentCreateParams.Builder()
    			.setCurrency(currency)
    			.setAmount(amount)
    			.build();
    	// Create a PaymentIntent with the order amount and currency
    	PaymentIntent intent = PaymentIntent.create(createParams);

    	CreatePaymentResponse paymentResponse = new CreatePaymentResponse(intent.getClientSecret());
    	return gson.toJson(paymentResponse);
    }
    
    
    @ExceptionHandler({ InvalidAmountException.class })
    public void handleException() {
        //
    }
    
}
