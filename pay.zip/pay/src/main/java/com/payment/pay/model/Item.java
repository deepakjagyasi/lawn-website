package com.payment.pay.model;

public class Item {

	 	public double amount;
	 	public String id;
	 	
	    public double getAmount() {
			return amount;
		}
		public void setAmount(double amount) {
			this.amount = amount;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		
}
