package com.payment.app.model;

public class Charge {
	
	private int amount;
	private String status;
	
	public Charge(int amount, String status) {
		super();
		this.amount = amount;
		this.status = status;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}


}
